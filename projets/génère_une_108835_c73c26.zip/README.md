mkd
# README.md

## Application To-Do List
### Fonctionnalités principal : Liste de tâches
### Langage : Python, Flask, SQLite
### Version : Tentative 4

## Table des matières
1. [Requisités](#Requisités)
2. [Installation](#Installation)
3. [Usage](#Usage)
4. [Fichier requirements.txt](#Fichier-requirements.txt)

## Requisités
- Python 3.8+
- Python pip
- Git

## Installation
### Clonez le repo
