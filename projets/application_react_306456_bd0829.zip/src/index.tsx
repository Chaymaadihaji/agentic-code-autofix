typescript
/**
 * src/index.tsx
 * Application React qui récupère des données de l'API JSONPlaceholder et les affiche dans un tableau avec pagination
 */

import React, { useState, useEffect } from 'react';
import './styles.css';

function App() {
  // Etat du composant
  const [data, setData] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [currentPage, setCurrentPage] = useState(1);
  const [postsPerPage] = useState(10);

  // Fichier JSONPlaceholder API
  const apiUrl = 'https://jsonplaceholder.typicode.com/posts';

  // Fonction pour afficher les données
  const displayData = (data: any) => {
    if (data === null || data.length === 0) {
      return <div>Aucun résultat trouvé</div>;
    }

    return (
      data
        .slice((currentPage - 1) * postsPerPage, currentPage * postsPerPage)
        .map((item: any) => {
          return (
            <div key={item.id} className="card">
              <h2>{item.title}</h2>
              <p>{item.body}</p>
            </div>
          );
        })
    );
  };

  // Fonction pour faire les requêtes API
  useEffect(() => {
    const fetchData = async () => {
      try {
        setLoading(true);
        const response = await fetch(apiUrl);
        const data = await response.json();

        setData(data);
        setLoading(false);
      } catch (error) {
        setError(error.message);
        setLoading(false);
      }
    };

    fetchData();

    // Effect for pagination
    window.addEventListener('scroll', handleScroll);
    return () => {
      window.removeEventListener('scroll', handleScroll);
    };
  }, [currentPage]);

  // Handle scroll for pagination
  const handleScroll = () => {
    const { scrollHeight, scrollTop, clientHeight } = document.documentElement;

    if (
      scrollHeight === scrollTop + clientHeight &&
      currentPage * postsPerPage <= data.length - 1
    ) {
      setCurrentPage(currentPage + 1);
    }
  };

  // Message d'erreur
  if (loading) {
    return <p>Chargement...</p>;
  }
  if (error) {
    return <p>{error}</p>;
  }

  // Retirer les résultats
  return (
    <div className="container">
      <h1>Tableau des posts</h1>
      <button onClick={() => setCurrentPage(1)}>Première page</button>
      <button onClick={() => setCurrentPage(currentPage + 1)}>Préc</button>
      <button onClick={() => setCurrentPage(currentPage - 1)}>Suivant</button>
      <table>
        <thead>
          <tr>
            <th>Titre</th>
            <th>Corps</th>
          </tr>
        </thead>
        <tbody>{displayData(data)}</tbody>
      </table>
    </div>
  );
}

export default App;
