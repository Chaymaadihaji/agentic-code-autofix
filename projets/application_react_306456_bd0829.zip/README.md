bash
npm install react react-dom axios
