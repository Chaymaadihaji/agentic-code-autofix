python
"""
main.py - FastAPI application
"""

from fastapi import FastAPI, Depends, HTTPException
from fastapi.security import OAuth2PasswordBearer, OAuth2PasswordRequestForm
from fastapi.responses import JSONResponse
from fastapi.requests import Request
from typing import Optional
from pydantic import BaseModel
from pymongo import MongoClient
from jose import jwt, JWTError
from datetime import datetime, timedelta
from passlib.context import CryptContext
from fastapi_docs import SwaggerUI
import json

# Configuration
API_PREFIX = "/api"
TOKEN_EXPIRE_MINUTES = 30
SECRET_KEY = "my_secret_key"

# MongoDB configuration
client = MongoClient("mongodb://localhost:27017/")
database = client["mydatabase"]
collection = database["mycollection"]

# FastAPI application
app = FastAPI(title="Mon API", version="1.0", description="API REST avec FastAPI et MongoDB")

# Swagger UI
origins = [
    "*"
]
app.add_event_handler("shutdown", SwaggerUIorig)

# Password hashing
pwd_context = CryptContext(schemes=["bcrypt"], default="bcrypt")

# JWT configuration
oauth2_scheme = OAuth2PasswordBearer(tokenUrl=f"{API_PREFIX}/login")

# Models
class User(BaseModel):
    id: str
    username: str
    email: str

class Token(BaseModel):
    access_token: str
    token_type: str

class TokenData(BaseModel):
    username: str | None = None

# Auth functions
def get_password_hash(password):
    return pwd_context.hash(password)

def verify_password(plain_password, hashed_password):
    return pwd_context.verify(plain_password, hashed_password)

def get_user(username: str):
    user = collection.find_one({"username": username})
    if user is None:
        raise HTTPException(status_code=404, detail="User not found")
    return User(id=str(user["_id"]), username=user["username"], email=user["email"])

def authenticate_user(username: str, password: str):
    user = get_user(username)
    if not verify_password(password, user.hashed_password):
        raise HTTPException(status_code=401, detail="Invalid password")
    return user

def create_access_token(data: dict, expires_delta: timedelta | None = None):
    to_encode = data.copy()
    if expires_delta:
        expire = datetime.utcnow() + expires_delta
    else:
        expire = datetime.utcnow() + timedelta(minutes=15)
    to_encode.update({"exp": expire})
    encoded_jwt = jwt.encode(to_encode, SECRET_KEY, algorithm="HS256")
    return encoded_jwt

# Routes
@app.post(f"{API_PREFIX}/login")
async def login_for_access_token(form_data: OAuth2PasswordRequestForm = Depends()):
    user = authenticate_user(form_data.username, form_data.password)
    access_token = create_access_token(
        data={"sub": user.username}, expires_delta=timedelta(minutes=TOKEN_EXPIRE_MINUTES)
    )
    return {"access_token": access_token, "token_type": "bearer"}

@app.get(f"{API_PREFIX}/users/me")
async def read_users_me(token: str = Depends(oauth2_scheme)):
    try:
        payload = jwt.decode_token(token,SECRET_KEY)
        user = get_user(payload["sub"])
        return {"username": user.username, "email": user.email}
    except JWTError:
        raise HTTPException(status_code=401, detail="Invalid token")

@app.get(f"{API_PREFIX}/users")
async def read_users():
    users = collection.find()
    return [User(id=user["_id"], username=user["username"], email=user["email"]) for user in users]
