bash
python -m venv env
